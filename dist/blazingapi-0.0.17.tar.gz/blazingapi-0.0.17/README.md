# BlazingAPI

Under construction! Not ready for use yet! Currently, experimenting and planning!

Developed by Nuno Lemos

## Examples of How To Use

Running server locally using Gunicorn

```python
from blazingapi.server import run 

run()
```