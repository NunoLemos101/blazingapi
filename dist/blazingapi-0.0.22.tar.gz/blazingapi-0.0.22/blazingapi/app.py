from blazingapi.router import Router

app = Router()
